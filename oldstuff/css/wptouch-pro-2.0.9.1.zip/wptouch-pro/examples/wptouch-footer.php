		</div>	
		<div id="footer" class="<?php wptouch_footer_classes(); ?>">
			<!-- some footer content -->
			
			<?php wptouch_footer(); ?>
		</div>
	</body>
</html>