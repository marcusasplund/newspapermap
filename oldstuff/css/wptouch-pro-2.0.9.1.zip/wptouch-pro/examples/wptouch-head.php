<head>
	<?php wptouch_head(); ?>
</head>