<?php if ( wptouch_api_server_down() ) { ?>
	<p class="api-warning round-6"><?php _e( "The license server is temporarily unavailable.", "wptouch-pro" ); ?><br /><?php _e( "If you continuously see this message, contact the BNC support team.", "wptouch-pro" ); ?></p>
<?php } ?>