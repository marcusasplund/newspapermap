++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
This copyright and license notice covers the images in this directory.
Note the license notice contains an add-on.
************************************************************************

TITLE:	Glossy eCommerce Icons Pack
AUTHOR:	Eoin McGrath | Starfish Web Consulting
SITE:		http://www.starfishwebconsulting.co.uk


Copyright (c)  2008  Starfish Web Consulting

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation,
version 2.1 of the License.
This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.
You should have received a copy of the GNU Lesser General Public
License along with this library (see the the license.txt file); if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#######**** NOTE THIS ADD-ON ****#######

DESCRIPTION:

Free icons for eCommerce web projects
Icons where designed using Inkscape, and then exported to PNG format.
Enjoy!

LICENSE

Released under GNU Lesser General Public License (LGPL)
Look at the license.txt file.

CONTACT

e-mail :		eoin [at] starfish.ie
http:           	http://www.starfishwebconsulting.co.uk
