Theme Name: Classic 2.0
Theme URI: http://www.bravenewcode.com/products/wptouch-pro/
Description: The next generation of the Classic WPtouch theme.
Version: 2.0.9.3
Author: Dale Mugford and Duane Storey
Features: All-new code, including new support for 2.0 features like Web-App mode.
Tags: classic, original