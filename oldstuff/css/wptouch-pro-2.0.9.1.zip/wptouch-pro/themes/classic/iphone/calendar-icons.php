<!-- Calendar Icons Code -->
<div class="calendar-box">
	<div class="cal-month <?php wptouch_date_classes(); ?>"><?php echo get_the_time( 'M' ) ?></div>
	<div class="cal-date <?php wptouch_date_classes(); ?>"><?php echo get_the_time( 'j' ) ?></div>
</div>				