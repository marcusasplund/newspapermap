Theme Name: Skeleton Template
Theme URI: http://www.bravenewcode.com/products/wptouch-pro/
Description: Use the Skeleton as a foundation for your own custom WPtouch theme.
Version: 1.0.8.1
Author: Dale Mugford and Duane Storey
Features: New menu system support, inline comment replies, and more! 
Tags: skeleton, template